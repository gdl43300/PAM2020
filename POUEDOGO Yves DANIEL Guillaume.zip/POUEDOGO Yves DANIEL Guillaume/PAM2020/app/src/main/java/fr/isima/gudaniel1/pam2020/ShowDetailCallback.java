package fr.isima.gudaniel1.pam2020;

public interface ShowDetailCallback {
    public void showDetail(Comic c);
}
